package JPetStore.JPetStoreAutomation;

public class JPetStoreReptilesCategory {

}
